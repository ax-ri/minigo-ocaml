package main
import "fmt"

func main() {
	fmt.Print("hello world!\n")
}
